import { CustomdatePipe } from './customdate.pipe';

describe('CustomdatePipe', () => {
  it('create an instance', () => {
    const pipe = new CustomdatePipe();
    expect(pipe).toBeTruthy();
  });
});
