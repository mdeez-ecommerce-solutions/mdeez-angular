import { Role } from './role';

export class User {
  role: Role;
}