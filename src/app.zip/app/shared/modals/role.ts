export enum Role {
    User = 'EDITORS',
    Admin = 'ADMIN'
  }